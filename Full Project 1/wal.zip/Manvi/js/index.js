/* Set the width of the sidebar to 220px (show it) */
function openNav() {
  document.getElementById("mySidepanel").style.width = "220px";
}

/* Set the width of the sidebar to 0 (hide it) */
function closeNav() {
  document.getElementById("mySidepanel").style.width = "0";
}